// // Import the functions you need from the SDKs you need
// import * as firebase from "firebase";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyBSqeE0RI-VQ_DvSEdUaufBESTWWGDUa1Y",
//   authDomain: "authfirebaseflashcard.firebaseapp.com",
//   projectId: "authfirebaseflashcard",
//   storageBucket: "authfirebaseflashcard.appspot.com",
//   messagingSenderId: "343967615054",
//   appId: "1:343967615054:web:23b0558fe3764313a8db1f"
// };

// // Initialize Firebase

// let app;
// if(firebase.apps.length === 0){
//     app = initializeApp(firebaseConfig);
// } else{
//     app = firebase.app();
// }

// const auth = firebase.auth();

// export { auth };